import React from 'react'
import { Link } from 'react-router-dom'

export default function home1() {
    return (
        <div>
            
            <section className="top-header">
                <div className="container">
                    <div className="row">
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            <div className="contact-number">
                            <Link className="pull-left" to="/">
                            <img className="media-object" src="assets/images/fas.jpg" alt="image" />
                             </Link>
                                
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Site Logo --> */}
                            <div className="logo text-center">
                                {/* <Link to="index.html">

                                </Link> */}
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Cart --> */}
                            <ul className="top-menu text-right list-inline">
                                <li className="dropdown cart-nav dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"><i
                                            className="tf-ion-android-cart"></i>Cart</Link>
                                    <div className="dropdown-menu cart-dropdown">
                                        {/* <!-- Cart Item --> */}
                                        <div className="media">
                                            <Link className="pull-left" to="#!">
                                                <img className="media-object" src="assets/images/shop/cart/cart-1.jpg" alt="image" />
                                            </Link>
                                            <div className="media-body">
                                                <h4 className="media-heading"><Link to="#!">Ladies Bag</Link></h4>
                                                <div className="cart-price">
                                                    <span>1 x</span>
                                                    <span>1250.00</span>
                                                </div>
                                                <h5><strong>$1200</strong></h5>
                                            </div>
                                            <Link to="#!" className="remove"><i className="tf-ion-close"></i></Link>
                                        </div> 
                                        {/* <!-- Cart Item --> */}
                                        <div className="media">
                                            <Link className="pull-left" to="#!">
                                                <img className="media-object" src="images/shop/cart/cart-2.jpg" alt="image" />
                                            </Link>
                                            <div className="media-body">
                                                <h4 className="media-heading"><Link to="#!">Ladies Bag</Link></h4>
                                                <div className="cart-price">
                                                    <span>1 x</span>
                                                    <span>1250.00</span>
                                                </div>
                                                <h5><strong>$1200</strong></h5>
                                            </div>
                                            <Link to="#!" className="remove"><i className="tf-ion-close"></i></Link>
                                        </div>

                                        <div className="cart-summary">
                                            <span>Total</span>
                                            <span className="total-price">$1799.00</span>
                                        </div>
                                        <ul className="text-center cart-buttons">
                                            <li><Link to="cart.html" className="btn btn-small">View Cart</Link></li>
                                            <li><Link to="checkout.html" className="btn btn-small btn-solid-border">Checkout</Link></li>
                                        </ul>
                                    </div>
                                </li>
                                {/* <!-- / Cart --> */}


                                {/* <!-- Search --> */}
                                <li className="dropdown search dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"><i
                                            className="tf-ion-ios-search-strong"></i> Search</Link>
                                    <ul className="dropdown-menu search-dropdown">
                                        <li>
                                            <form action="post"><input type="search" className="form-control" placeholder="Search..." /></form>
                                        </li>
                                    </ul>
                                </li>
                                {/* <!-- / Search --> */}

                                {/* <!-- Languages --> */}
                                <li className="commonSelect">
                                    <select className="form-control">
                                        <option>English</option>
                                        <option>Japanese</option>
                                        <option>Russian</option>
                                        <option>French</option>
                                    </select>
                                </li>
                                {/* <!-- / Languages --> */}

                            </ul>
                            {/* <!-- / .nav .navbar-nav .navbar-right --> */}
                        </div>
                    </div>
                </div>
            </section>
            {/* <!-- End Top Header Bar --> */}


            {/* <!-- Main Menu Section --> */}
            <section className="menu">
                <nav className="navbar navigation">
                    <div className="container">
                        <div className="navbar-header">
                            <h2 className="menu-title">Main Menu</h2>
                            <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                                aria-expanded="false" aria-controls="navbar">
                                <span className="sr-only">Toggle navigation</span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                            </button>
                        </div>
                        {/* <!-- / .navbar-header --> */}

                        {/* <!-- Navbar Links --> */}
                        <div id="navbar" className="navbar-collapse collapse text-center">
                            <ul className="nav navbar-nav">

                                {/* <!-- Home --> */}
                                <li className="dropdown ">
                                    <Link to="/">Home</Link>
                                </li>
                                {/* <!-- / Home --> */}

                                {/* <!-- Elements --> */}
                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                        role="button" aria-haspopup="true" aria-expanded="false">Catalogue <span
                                            className="tf-ion-ios-arrow-down"></span></Link>
                                    <div className="dropdown-menu">
                                        <div className="row">
                                            {/* <!--  --> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                                <ul>
                                                    <li className="dropdown-header">Pages</li>
                                                    <li role="separator" className="divider"></li>
                                                    <li><Link to="/Checkout">CheckOut</Link></li>
                                                    <li><Link to="/Cart">Cart</Link></li>
                                                </ul>
                                            </div>
                                        </div>
                                        {/* <!-- / .row --> */}
                                    </div>
                                    {/* <!-- / .dropdown-menu --> */}
                                </li>
                                {/* <!-- / Elements --> */}


                                {/* <!-- Pages --> */}
                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                        role="button" aria-haspopup="true" aria-expanded="false">Catalogue <span
                                            className="tf-ion-ios-arrow-down"></span></Link>
                                    <div className="dropdown-menu">
                                        <div className="row">
                                            {/* <!-- For Him --> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                                <ul>
                                                    <li className="dropdown-header">For Him</li>
                                                    <li role="separator" className="divider"></li>
                                                    <li><Link to="/ProductCatalogue">Sherwani</Link></li>
                                                    <li><Link to="/ProductCatalogue">Tuxedo</Link></li>
                                                    <li><Link to="/ProductCatalogue">Kurta Pyjama</Link></li>
                                                </ul>
                                            </div>
                                            
                                            {/* <!--For Her--> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                                <ul>
                                                    <li className="dropdown-header">For Her</li>
                                                    <li role="separator" className="divider"></li>
                                                    <li><Link to="/ProductCatalogue">Lehenga</Link></li>
                                                    <li><Link to="/ProductCatalogue">Gowns</Link></li>
                                                    <li><Link to="/ProductCatalogue">Indo-Western</Link></li>
                                                </ul>
                                            </div>
                                        </div>
                                        {/* <!-- / .row --> */}
                                    </div>
                                    {/* <!-- / .dropdown-menu --> */}
                                </li>
                                {/* <!-- / Pages --> */}

                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                    role="button" aria-haspopup="true" aria-expanded="false">Dashboard<span
                                        className="tf-ion-ios-arrow-down"></span></Link>

                                        <div className="dropdown-menu">
                                            <div className="row">
                                                
                                                {/* <!-- Contact --> */}
                                                <div className="col-lg-12 col-md-6 mb-sm-3">
                                                    <ul>
                                                        <li><Link to="/Order">Orders</Link></li>
                                                        <li><Link to="/Address">Address</Link></li>
                                                        <li><Link to="/profileDetails">Profile Details</Link></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            {/* <!-- / .row --> */}
                                        </div>
                                        {/* <!-- / .dropdown-menu --> */}
                                </li>

                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle w-25 p-3" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                    role="button" aria-haspopup="true" aria-expanded="false">Login Details<span
                                        className="tf-ion-ios-arrow-down"></span></Link>
                                        <div className="dropdown-menu">
                                            <div className="row ">
                                                {/* <!-- Utility --> */}
                                                <div className="col-lg-12 col-md-6 mb-sm-3">
                                                    <ul>
                                                        <li><Link to="/Login">Login Page</Link></li>
                                                        <li><Link to="/signUp">Signin Page</Link></li>
                                                        <li><Link to="/forgetPassword">Forget Password</Link></li>
                                                        <li><Link to="/VendorSignUp">VendorSignUp</Link></li>
                                                        <li><Link to="/AdminLogin">AdminLogin</Link></li>

                                                    </ul>
                                                </div>
                                            </div>
                                            {/* <!-- / .row --> */}
                                        </div>
                                        {/* <!-- / .dropdown-menu --> */}
                                </li>
                            </ul>
                            {/* <!-- / .nav .navbar-nav --> */}
                        </div>
                        {/* <!--/.navbar-collapse --> */}
                    </div>
                    {/* <!-- / .container --> */}
                </nav>
            </section> 


            {/* <div className="hero-slider">
            <div className="slider-item th-fullpage hero-area" style={{"backgroundImage": 'url("images/slider/slider-1.jpg")'}}>
                <div className="container">
                <div className="row">
                    <div className="col-lg-8 text-center">
                    <h1 data-duration-in=".3" data-animation-in="fadeInUp" data-delay-in=".5">!!Go on Fashion by your Choice!!</h1>
                    <Link data-duration-in=".3" data-animation-in="fadeInUp" data-delay-in=".8" className="btn" to="shop.html">Shop Now</Link>
                    </div>
                </div>
                </div>
            </div>
            </div> */}


            {/* <section className="product-category section">
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <div className="title text-center">
                                <h2>Product Category</h2>
                            </div>
                        </div>
                        <div className="col-md-6">
                            <!-- image to be change afterwords -->
                            <div className="category-box">
                                <Link to="#!">
                                    <img src="images/shop/category/category-1.jpg" alt="" />
                                </Link>	
                            </div>

                        </div>
                        <!-- image to be change afterwords -->
                        <div className="col-md-6">
                            <div className="category-box">
                                <Link to="#!">
                                    <img src="images/shop/category/category-3.jpg" alt="" />
                                </Link>	
                            </div>
                        </div>
                    </div>
                </div>
            </section> */}

{/*
             <section className="products section bg-gray">
                <div className="container">
                    <div className="row">
                        <div className="title text-center">
                            <h2>Trendy Products</h2>
                        </div>
                    </div>
                    <div className="row">
                        
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <span className="bage">Sale</span>
                                    <img className="img-responsive" src="images/shop/products/product-1.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#!" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Reef Boardsport</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <img className="img-responsive" src="images/shop/products/product-2.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Rainbow Shoes</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <img className="img-responsive" src="images/shop/products/product-3.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Strayhorn SP</Link></h4>
                                    <p className="price">$230</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <img className="img-responsive" src="images/shop/products/product-4.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Bradley Mid</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <img className="img-responsive" src="images/shop/products/product-5.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Rainbow Shoes</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <img className="img-responsive" src="images/shop/products/product-6.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Rainbow Shoes</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <span className="bage">Sale</span>
                                    <img className="img-responsive" src="images/shop/products/product-7.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Rainbow Shoes</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <img className="img-responsive" src="images/shop/products/product-8.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Rainbow Shoes</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="product-item">
                                <div className="product-thumb">
                                    <img className="img-responsive" src="images/shop/products/product-9.jpg" alt="product-img" />
                                    <div className="preview-meta">
                                        <ul>
                                            <li>
                                                <span  data-toggle="modal" data-target="#product-modal">
                                                    <i className="tf-ion-ios-search-strong"></i>
                                                </span>
                                            </li>
                                            <li>
                                                <Link to="#" ><i className="tf-ion-ios-heart"></i></Link>
                                            </li>
                                            <li>
                                                <Link to="#!"><i className="tf-ion-android-cart"></i></Link>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="product-content">
                                    <h4><Link to="product-single.html">Rainbow Shoes</Link></h4>
                                    <p className="price">$200</p>
                                </div>
                            </div>
                        </div> 
                    
                
                        <div className="modal product-modal fade" id="product-modal">
                        <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                            <i className="tf-ion-close"></i>
                        </button>
                        <div className="modal-dialog " role="document">
                            <div className="modal-content">
                                <div className="modal-body">
                                    <div className="row">
                                        <div className="col-md-8 col-sm-6 col-xs-12">
                                            <div className="modal-image">
                                                <img className="img-responsive" src="images/shop/products/modal-product.jpg" alt="product-img" />
                                            </div>
                                        </div>
                                        <div className="col-md-4 col-sm-6 col-xs-12">
                                            <div className="product-short-details">
                                                <h2 className="product-title">GM Pendant, Basalt Grey</h2>
                                                <p className="product-price">$200</p>
                                                <p className="product-short-description">
                                                    Fashion on Rent Welcomes you!!!!
                                                </p>
                                                <Link to="cart.html" className="btn btn-main">Add To Cart</Link>
                                                <Link to="product-single.html" className="btn btn-transparent">View Product Details</Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 

                    </div> 
                </div> 
            </section>  
*/}

        </div> 
    )
}
