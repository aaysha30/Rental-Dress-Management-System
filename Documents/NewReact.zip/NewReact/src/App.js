//import logo from './logo.svg';
import './App.css';
import React from 'react';
import {
  BrowserRouter as Router,
  Route,
  Link,
  Routes
} from "react-router-dom";
import Home from './pages/Home';
import ProductCatalogue from './pages/ProductCatalogue';
import ProductDetails from './pages/ProductDetails';
import Cart from './pages/Cart';
import Login from './pages/Login';
import Signup from './pages/Signup';
import VendorSignup from './pages/VendorSignUp';
import ForgetPassword from './pages/ForgotPassword';
import Dashboard from './pages/Dashboard';
import Checkout from './pages/Checkout';
import Address from './pages/Address';
import Order from './pages/Order';
import ProfileDetails from './pages/ProfileDetails';
import AdminLogin from './pages/AdminLogin';

function App() {
  return (
    <Router>
    <div className="App">
      {/* <Home></Home> */}
      {/* <ProductCatalogue></ProductCatalogue> */}
      {/* <Home1></Home1> */}
      {/* <Dashboard></Dashboard> */}
      
      <Routes>
      <Route exact path='/' element={<Home></Home>}/>
      <Route exact path='/ProductCatalogue' element={<ProductCatalogue></ProductCatalogue>}/>
      <Route exact path='/ProductDetails' element={<ProductDetails></ProductDetails>}/>
      <Route exact path='/Checkout' element={<Checkout></Checkout>}/>
      <Route exact path='/Login' element={<Login></Login>}/>
      <Route exact path='/Signup' element={<Signup></Signup>}/>
      <Route exact path='/VendorSignup' element={<VendorSignup></VendorSignup>}/>
      <Route exact path='/ForgetPassword' element={<ForgetPassword></ForgetPassword>}/>
      <Route exact path='/Cart' element={<Cart></Cart>}/>
      <Route exact path='/Address' element={<Address></Address>}/>
      <Route exact path='/Order' element={<Order></Order>}/>
      <Route exact path='/ProfileDetails' element={<ProfileDetails></ProfileDetails>}/>
      <Route exact path='/Dahboard' element={<Dashboard></Dashboard>}/>
      <Route exact path='/AdminLogin' element={<AdminLogin></AdminLogin>}/>
      </Routes>
   
    </div>
    </Router>
  );
}

export default App;
