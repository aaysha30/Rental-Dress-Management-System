package com.example.demo;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="my_order_details_tbl")
public class OrderedApparelEntity {

@Id 
@GeneratedValue
@Column
private int id; 
@Column
private int apparelId;
@Column
private String  order_id;
	

	public OrderedApparelEntity(int apparelId, String order_id) {
	super();
	this.apparelId = apparelId;
	this.order_id = order_id;
}

	public int getApparelId() {
		return apparelId;
	}

	public void setApparelId(int apparelId) {
		this.apparelId = apparelId;
	}

	public OrderedApparelEntity() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOrder_Id() {
		return order_id;
	}

	public void setOrder_Id(String order_Id) {
		this.order_id = order_Id;
	}
}
