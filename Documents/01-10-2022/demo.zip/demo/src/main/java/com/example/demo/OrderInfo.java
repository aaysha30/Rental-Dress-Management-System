package com.example.demo;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class OrderInfo {
	private String order_id;

	private int rent_amount;

	private int deposit_amount;

	private int total_amount;
	
	private String delievery_address;
	
	private Date date_of_dispatch;

	private Date date_of_return;
	
	private int cid;
	
	//private List<Integer> aid;

	//private String[] aid ;
	public OrderInfo(String order_id, int rent_amount, int deposit_amount, int total_amount,
			String delievery_address, Date date_of_dispatch, Date date_of_return,int cid) //int cid,S[]aid)// List<Integer> aid) {
	{
	super();
		//this.aid=new String[5];
	//this.aid=aid;
		this.order_id = order_id;
		this.rent_amount = rent_amount;
		this.deposit_amount = deposit_amount;
		this.total_amount = total_amount;
		this.delievery_address = delievery_address;
		this.date_of_dispatch = date_of_dispatch;
		this.date_of_return = date_of_return;
		this.cid = cid;
		//this.aid = aid;
	}

	public OrderInfo() {
		
		super();
	//	aid=new String[5];
	}

	public String getOrder_id() {
		return order_id;
	}

	public void setOrder_id(String order_id) {
		this.order_id = order_id;
	}

	public int getRent_amount() {
		return rent_amount;
	}

	public void setRent_amount(int rent_amount) {
		this.rent_amount = rent_amount;
	}

	public int getDeposit_amount() {
		return deposit_amount;
	}

	public void setDeposit_amount(int deposit_amount) {
		this.deposit_amount = deposit_amount;
	}

	public int getTotal_amount() {
		return total_amount;
	}

	public void setTotal_amount(int total_amount) {
		this.total_amount = total_amount;
	}

	public String getDelievery_address() {
		return delievery_address;
	}

	public void setDelievery_address(String delievery_address) {
		this.delievery_address = delievery_address;
	}

	public Date getDate_of_dispatch() {
		return date_of_dispatch;
	}

	public void setDate_of_dispatch(Date date_of_dispatch) {
		this.date_of_dispatch = date_of_dispatch;
	}

	public Date getDate_of_return() {
		return date_of_return;
	}

	public void setDate_of_return(Date date_of_return) {
		this.date_of_return = date_of_return;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

//	public List<Integer> getAid() {
//		return aid;
//	}
//
//	public void setAid(List<Integer> aid) {
//		this.aid = aid;
//	}

//	public List<Integer> getAid() {
//		return aid;
//	}
//
//	public void setAid(List<Integer> aid) {
//		this.aid = aid;
//	}
	
}
