import axios from 'axios';
import React, { useState } from 'react'
import { useSelector } from 'react-redux';
import {Link, useNavigate} from 'react-router-dom'
import { v4 as uuid } from 'uuid';
export default function Checkout2(props) {
    //   const [dateOfDispatch,setDateOfDispatch]=useState();
    //   const [address,setAddress]=useState('');
    //   const[depositAmount,setDepositAmount]=useState()
    //   const[rentAmount,setRentAmount]=useState()
    //   const[totalAmount,setTotalAmount]=useState()
    //   const [totalRent,setTotalRent]=useState(0)
    //   const [totalDeposit,setTotalDeposit]=useState(0)
    //   const[dateOfReturn,setDateOfReturn]=useState();
    
    //   const a=0;
    //   const cartList = useSelector((state) => {
    //     return state.cartItems.map((e) => {
    //         return {
    //             apparelId : e.apparelId,
    //             description : e.description,
    //             rent_amount : e.rent_amount,
    //             deposit_amount : e.deposit_amount,
    //             gender : e.gender,
    //             status : e.status,
    //         }
    //     });
    // });

    // let finalDeposit=cartList.map((product)=>product.deposit_amount).reduce((prev,current)=>prev+current,0)
    //     console.log("Final Deposit Amount : "+finalDeposit)

    // let finalRent=cartList.map((product)=>product.rent_amount).reduce((prev,current)=>prev+current,0)
    // console.log("Final Rent Amount: "+finalRent)

    // const cid=useSelector(state=>{
    //   console.log("Checkout Page ->  cid: "+state.roleId)
    //   return state.roleId;
    // });
    // var total=finalDeposit+finalRent
    // console.log("Total Amount : "+total)

    // function HandlerDate(e){
    //       console.log("Handler")
    //       var dod=e.target.value
    //       setDateOfDispatch(dod);
    //       console.log("date of dispatch "+dod)
    //       var d=new Date(e.target.value)
    //       console.log(d)
    //       d.setDate(d.getDate()+4);
    //       console.log("dor :"+d)
    //       var m=d.getMonth()+1
    //       var str=d.getDate()+"-"+m+"-"+d.getFullYear()
    //     setDateOfReturn(str)
    //     console.log(dateOfReturn)
    // }

    // function HandlerAddress(e){
    //     console.log("Address : "+e.target.value)
    //     setAddress(e.target.value())
    // }

    // function HandlerPlaceOrder(e){

    //   e.preventDefault();
    //         axios.post('http://localhost:8080/orders/placeorder', {
    //             customer_id: cid,
    //             date_of_dispatch:dateOfDispatch,
    //             date_of_return:dateOfReturn,
    //             delievery_address:address,
    //             deposit_amount:depositAmount,
    //             rent_amount:rentAmount,
    //             status:"Available",
    //             total_amount:total
    //         })
    //          .then(result =>{
    //             alert("Order Placed !!")
    //         })
    //          .catch(error => {
    //             console.log(error);
    //         })
    // }
    const [dateOfDispatch,setDateOfDispatch]=useState();
    const [address,setAddress]=useState('');
    const[depositAmount,setDepositAmount]=useState()
    const[rentAmount,setRentAmount]=useState()
    const[totalAmount,setTotalAmount]=useState()
    const [totalRent,setTotalRent]=useState(0)
    const [totalDeposit,setTotalDeposit]=useState(0)
    const[dateOfReturn,setDateOfReturn]=useState();
    const fname=useSelector(state=>{ return state.fname});
    const category1="Sherwani";
    const category2="Tuxedo";
    const category3="Kurta";
    const category4="Lehenga";
    const category5="Gown"; 
    const category6="Western";
    const f=fname.toUpperCase()
 
   
    const a=0;
     const cartList = useSelector((state) => {
      return state.cartItems.map((e) => {
          return {
              apparelId : e.apparelId,
              description : e.description,
              rent_amount : e.rent_amount,
              deposit_amount : e.deposit_amount,
              gender : e.gender,
              status : e.status,
          }
      });
  });
  let da=0;
  let ra=0;
  cartList.map((e)=>{
    da=e.deposit_amount
    console.log("check.1."+da)
    ra=e.rent_amount
    console.log("check.2."+ra)
  })
  let finalDeposit=cartList.map((product)=>product.deposit_amount).reduce((prev,current)=>prev+current,0)
      console.log("Final Deposit Amount : "+finalDeposit)
  
  let finalRent=cartList.map((product)=>product.rent_amount).reduce((prev,current)=>prev+current,0)
  console.log("Final Rent Amount: "+finalRent)
  ///var t=finalDeposit
  //setTotalAmount(finalDeposit)
  // console.log("Total Amount :"+totalAmount)


  let cid=useSelector(state=>{
    console.log("Checkout Page ->  cid: "+state.roleId)
    return state.roleId
  });
  console.log("Customer id->??? : "+cid)


  var total=finalDeposit+finalRent
  console.log("Total Amount : "+total)
  const navigate=useNavigate()
 

  const arr=[];
const aidList = useSelector((state) => {
    return state.cartItems.map((e) => {
        arr.push(e.apparelID)
        return arr;
        });
});
console.log(aidList.map((a)=>{console.log("My aid : "+a)}))




  function HandlerDate(e){
                console.log("Handler")
                var dod=e.target.value
                setDateOfDispatch(dod);
                console.log("date of dispatch "+dod)
                var d=new Date(e.target.value)
                console.log(d)
                d.setDate(d.getDate()+4);
                console.log("dor :"+d)
                var m=d.getMonth()+1
                var m1="";
                var date1=d.getDate();
                var str1="";
                if(m<10){
                    m1="0"+""+m
                    if(date1<10){
                        date1=0+""+date1
                    }
                     str1=d.getFullYear()+"-"+m1+"-"+date1
                    
                }
                else{
                    if(date1<10){
                        date1=0+""+date1
                    }
                     str1=d.getFullYear()+"-"+m+"-"+date1
                   
                }
                setDateOfReturn(str1)
               // var str=d.getDate()+"-"+m+"-"+d.getFullYear()
             //  var str1=d.getFullYear()+"-"+m+"-"+d.getDate()
                setDateOfReturn(str1)
                console.log(dateOfReturn)
            
  }
 
  function HandlerAddress(e){
    console.log("Address : "+e.target.value)
    setAddress(e.target.value)
  }
console.log("Delievery adress : "+address)

  function HandlerPlaceOrder(e){
                console.log("placeorder..")
                e.preventDefault();
                const unique_id =uuid();
                const small_id = unique_id.slice(0,2)
                console.log("small id : "+small_id)
                console.log("uuid : "+small_id)
       
                axios.post(`http://localhost:8080/placeorderdress/${aidList}`, {
                    order_id:small_id,
                
                    date_of_dispatch:dateOfDispatch,
                    date_of_return:dateOfReturn,
                    delievery_address:address,
                    deposit_amount:da,
                    rent_amount:ra,
                    status:"Available",
                    total_amount:total,
                    cid:cid,
                    
                }) .then(result =>{
                    alert("Order Placed !!")
                    navigate('/')
                }
                )
                .catch(error => {
                    console.log(error);
                })
  }

    return (

          <div>
                <section className="top-header">
                <div className="container">
                    <div className="row">
                        <div className="col-md-4 col-xs-12 col-sm-4">
                        <div className=" Fashion Logo">
                            <Link className="pull-left" to="/">
                            <img className="media-object" src="assets/images/logo/fas.jpg" width="80px" height="80px" alt="image" />
                             </Link>
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Site Logo --> */}
                            <div className="logo text-center">
                                <Link to="/">
							<h1>FASHION ON RENT</h1>

                                </Link>
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Cart --> */}
                            <ul className="top-menu text-right list-inline">
                                <li className="dropdown cart-nav dropdown-slide">
                                    <Link to="/cartsession" className="dropdown-toggle" ><i
                                            className="tf-ion-android-cart"></i>Cart</Link>
                                </li>
                                {/* <!-- / Cart --> */}


                                {/* <!-- Search --> */}
                                <li className="dropdown search dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" > HELLO {f}</Link>
                                    {/* <ul className="dropdown-menu search-dropdown">
                                        <li>
                                            <form action="post"><input type="search" className="form-control" placeholder="Search..." /></form>
                                        </li>
                                    </ul> */}
                                </li>
                                {/* <!-- / Search --> */}

                                {/* <!-- Languages --> */}
                                <li className="">
                                <Link to={"/login"}>Login</Link>
                                </li>
                                {/* <!-- / Languages --> */}

                            </ul>
                            {/* <!-- / .nav .navbar-nav .navbar-right --> */}
                        </div>
                    </div>
                </div>
            </section>

            <section className="menu">
                <nav className="navbar navigation">
                    <div className="container">
                        <div className="navbar-header">
                            <h2 className="menu-title">Main Menu</h2>
                            <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                                aria-expanded="false" aria-controls="navbar">
                                <span className="sr-only">Toggle navigation</span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                            </button>
                        </div>
                        {/* <!-- / .navbar-header --> */}

                        {/* <!-- Navbar Links --> */}
                        <div id="navbar" className="navbar-collapse collapse text-center">
                            <ul className="nav navbar-nav">

                                {/* <!-- Home --> */}
                                <li className="dropdown ">
                                    <Link to="/">Home</Link>
                                </li>
                                {/* <!-- / Home --> */}

                                {/* <!-- Pages --> */}
                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                        role="button" aria-haspopup="true" aria-expanded="false">Catalogue <span
                                            className="tf-ion-ios-arrow-down"></span></Link>
                                    <div className="dropdown-menu">
                                        <div className="row">
                                            {/* <!-- For Him --> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                            <ul>
														<li className="dropdown-header">For Him</li>
														<li role="separator" className="divider"></li>
														 
                                                        <li><Link to={`/productByCategory/${category1}`}>Sherwani</Link></li>
                                                    <li><Link to={`/productByCategory/${category2}`}>Tuxedo</Link></li>
                                                    <li><Link to={`/productByCategory/${category3}`}>Kurta Pyjama</Link></li>
                                               
													</ul>
                                            </div>
                                            
                                            {/* <!--For Her--> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                            <ul>
														<li className="dropdown-header">For Her</li>
														<li role="separator" className="divider"></li>
                                                    <li><Link to={`/productByCategory/${category4}`}>Lehenga</Link></li>
                                                    <li><Link to={`/productByCategory/${category5}`}>Gowns</Link></li>
                                                    <li><Link to={`/productByCategory/${category6}`}>Western</Link></li>
                                                </ul>
                                            </div>
                                        </div>
                                        {/* <!-- / .row --> */}
                                    </div>
                                    {/* <!-- / .dropdown-menu --> */}
                                </li>
                                {/* <!-- / Pages --> */}

                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                    role="button" aria-haspopup="true" aria-expanded="false">Dashboard<span
                                        className="tf-ion-ios-arrow-down"></span></Link>

                                        <div className="dropdown-menu">
                                            <div className="row">
                                                
                                                {/* <!-- Contact --> */}
                                                <div className="col-lg-12 col-md-6 mb-sm-3">
                                                    <ul>
                                                        <li><Link to="/preorder">Orders</Link></li>
                                                        <li><Link to="/preprofile">Profile Details</Link></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            {/* <!-- / .row --> */}
                                        </div>
                                        {/* <!-- / .dropdown-menu --> */}
                                </li>
                            </ul>
                            {/*  / .nav .navbar-nav */}
                        </div>
                        {/* /.navbar-collapse  */}
                    </div>
                    {/* <!-- / .container --> */}
                </nav>
            </section> 

              <section className="page-header">
                  <div className="container">
                      <div className="row">
                          <div className="col-md-12">
                              <div className="content">
                                  <h1 className="page-name">Checkout</h1>
                                  <ol className="breadcrumb">
                                      <li><Link to="/home">Home</Link></li>
                                      <li className="active">checkout</li>
                                  </ol>
                              </div>
                          </div>
                      </div>
                  </div>
              </section>

              <div className="page-wrapper">
            <div className="checkout shopping">
                <div className="container">
                    <div className="row">
                        <div className="col-md-4">
                        <div className="block billing-details">
                       
                            <h4 className="widget-title">Billing Details</h4>
                            <form className="checkout-form">
                            <div className="form-group">
                                    <label htmlFor="dod">Date of dispatch</label>
                                    <input type="date" className="form-control" id="dod" placeholder="" onChange={HandlerDate}/>
                                </div>
                                {/* <div className="form-group">
                                    <label htmlFor="full_name">Full Name</label>
                                    <input type="text" className="form-control" id="full_name" placeholder=""/>
                                </div> */}
                         
                                <div className="form-group">
                                    <label htmlFor="user_address">Address</label>
                                    <input type="text" className="form-control" id="user_address" placeholder="" onChange={HandlerAddress} required />
                                </div>
                                {/* <div className="checkout-country-code clearfix">
                                    <div className="form-group">
                                    <label htmlFor="user_post_code">Zip Code</label>
                                    <input type="text" className="form-control" id="user_post_code" name="zipcode" defaultvalue=""/>
                                    </div>
                                    <div className="form-group" >
                                    <label htmlFor="user_city">City</label>
                                    <input type="text" className="form-control" id="user_city" name="city" defaultvalue=""/>
                                    </div>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="user_country">Country</label>
                                    <input type="text" className="form-control" id="user_country" placeholder=""/>
                                </div> */}
                            </form>
                        </div>
                        
                        </div>

                        <div className="col-md-8">
                              <div className="block">
                                  <div className="product-list">
                                  <form method="post">
                                      <table className="table">
                                      <thead>
                                          <tr>
                                              <th className="">Dispatch Date</th>
                                              <th className="">Return Date</th>
                                              <th className="">Description</th>
                                              <th className="">Deposit Amount</th>
                                              <th className="">Rent Amount</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                          {cartList.map((e) => {
                                         
                                            console.log("dor : "+dateOfReturn)
                                              return (
                                                  <tr className="">
                                                       <td className="">{dateOfDispatch}</td>
                                                      <td className="">{dateOfReturn}</td>
                                                      <td className="">{e.description}</td>
                                                      <td className="">{e.deposit_amount}</td>
                                                      <td className="">{e.rent_amount}</td>
                                                  </tr>
                                           
                                              )
                                          })}
                                                  {/* <tr className="">
                                                      <td></td>
                                                      <td></td>
                                                      <td></td>
                                                 Total deposit:<td>{finalDeposit}</td>
                                                 Total Rent :<td>{finalRent}</td>
                                                 Total Amount :<td>{finalDeposit + finalRent}</td> */}
                                                      {/* <td><input type="submit" value="Place Order" className='btn btn-main' onClick={HandlerPlaceOrder}/></td> */}
                                                  {/* </tr> */}
                                      </tbody>
                                      </table>
                                     
                                      <Link to="/home" className="btn btn-main pull-right" onClick={HandlerPlaceOrder}>Place Order</Link>
                                  </form>
                                  </div>
                              </div>
                        </div>
                        
                    </div>
                </div>
            </div>
              </div>

              <footer className="footer section text-center">
                  <div className="container">
                      <div className="row">
                          <div className="col-md-12">
                              {/* <ul className="social-media">
                                  <li>
                                      <Link to="https://www.facebook.com/themefisher">
                                          <i className="tf-ion-social-facebook"></i>
                                      </Link>
                                  </li>
                                  <li>
                                      <Link to="https://www.instagram.com/themefisher">
                                          <i className="tf-ion-social-instagram"></i>
                                      </Link>
                                  </li>
                                  <li>
                                      <Link to="https://www.twitter.com/themefisher">
                                          <i className="tf-ion-social-twitter"></i>
                                      </Link>
                                  </li>
                                  <li>
                                      <Link to="https://www.pinterest.com/themefisher/">
                                          <i className="tf-ion-social-pinterest"></i>
                                      </Link>
                                  </li>
                              </ul> */}
                              <ul className="footer-menu text-uppercase">
                                  <li>
                                      <Link to="contact.html">CONTACT</Link>
                                  </li>
                                  <li>
                                      <Link to="shop.html">SHOP</Link>
                                  </li>
                                  <li>
                                      <Link to="pricing.html">Pricing</Link>
                                  </li>
                                  <li>
                                      <Link to="contact.html">PRIVACY POLICY</Link>
                                  </li>
                              </ul>
                          </div>
                      </div>
                  </div>
              </footer>

          </div>

    ) 
}
