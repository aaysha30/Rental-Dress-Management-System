import React from 'react'
import { Link } from 'react-router-dom'
import { useEffect, useState } from "react";
import axios from "axios";


export default function VendorHome(){


    return(

        <div>
                <section className="top-header">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-4 col-xs-12 col-sm-4">
                                <div className="contact-number">
                                    <Link to="/login"><img className='media-object' width="80px" height="80px" src='/assets/images/logo/fas.jpg' /></Link>
                                </div>
                            </div>
                            <div className="col-md-4 col-xs-12 col-sm-4">
                                
                                <div className="logo text-center">
                                    <Link to="/home">
                                        <h2>FASHION ON RENT</h2>
                                    </Link>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </section>

                <section className="page-header">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="content">
                                    <h1 className="page-name">Vendor Home</h1>
                                    <ol className="breadcrumb">
                                    <li><Link to="/collection">Home</Link></li>
                                        <li className="active">my account</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="user-dashboard page-wrapper">
                    <div className="container">
                        <div className="row">
                            <div className="col-md-12">
                                <ul className="list-inline dashboard-menu text-center">
                                    <li><Link  to="/uploadApparel">Upload Apparel</Link></li>
                                    <li><Link  to="/collection">View Apparel Collection</Link></li>
                                    <li><Link  to="/prelogout" >Logout</Link></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </section>

        </div>
    )
}