import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import  axios from 'axios';
import emailjs from 'emailjs-com';
export default function Signup() { 
    const [first_name, setFirst_name] = useState('');
    const [last_name, setLast_name] = useState('');
    const [mobile_no, setMobile_no] = useState('');
    const [emailId, setEmailId] = useState('');
    const [password, setPassword] = useState('');
    const [address, setAddress] = useState('');
    const [numericcode, setNumericcode] = useState('');
    const navigateto = useNavigate();
    const [shownumber, setShownumber] = useState(Math.floor(100000 + Math.random() * 900000));

    useEffect(()=>{
        console.log(shownumber);
    },[])

    const handleFname = (em) => {
        setFirst_name(em.target.value);
    }
    const handleLname = (em) => {
        setLast_name(em.target.value);
    }
    const handleMoblieno = (em) => {
        setMobile_no(em.target.value);
    }
    const handleEmail = (em) => {
       setEmailId(em.target.value);
    }
    const handlePassword = (pwd) => {
        setPassword(pwd.target.value);
    }
    const handleAddress = (em) => {
        setAddress(em.target.value);
    }
    const handleNumericCode = (em) => {
        setNumericcode(em.target.value);
    }
       
   

    const handleEmailVerificationForVendor = (em) => {

        em.preventDefault();

        emailjs.send('service_nkozgdm', 'template_pebfizg', {
            first_name : first_name,
            last_name : last_name,
            numericcode : shownumber,
            email_Id : emailId
        }, "fa8V8lvoAejIiAXP0")
        .then(result=>{
            console.log(result)
        }).catch(error=>{
            console.log(error);
        })
        alert("Verification OTP send successfully on Email");
    }

    const handleSignAsVendor = (e) => {
        e.preventDefault();
        axios.post('http://localhost:8080/vendor/addvendor', {
            first_name : first_name,
            last_name : last_name,
            mobile_no : mobile_no,
            emailId : emailId,
            password : password,
            address : address,
})
            .then(result => {
                alert("Registration success")
                console.log("Registered")
                navigateto('/login');
               
            })
            .catch(error => {
                console.log(error);
            })}
    return (
        <div>
        <section className="signin-page account homeimage">
            <div className="container">
                <div className="row justify-content-center">
                <div className="col-md-6 col-md-offset-3">
                    <div className="block text-center my-3">
                    <h2 className="text-center">Vendor SignUp</h2>
                    <form className="text-left clearfix my-3" action="/">
                        <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="First Name" name='first_name' onChange={handleFname} required />
                        </div>
                        <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="Last Name"  name='last_name' onChange={handleLname} required />
                        </div>
                        <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="Mobileno"  name='mobile_no' onChange={handleMoblieno} required />
                        </div>
                        <div className="form-group">
                            <input type="email" className="form-control my-3"  placeholder="Email" name='email_Id' onChange={handleEmail} required  />
                        </div>
                        <div className="form-group">
                            <input type="password" className="form-control my-3"  placeholder="Password" name='password' onChange={handlePassword} required />
                        </div>
                        <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="Address"  name='address' onChange={handleAddress} required />
                        </div>
                        <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="Enter 6 digit code to verify email" name='numericcode' onChange={handleNumericCode} required />
                        </div>
                        <div className="text-center">
                            <button className="btn btn-main" onClick={handleEmailVerificationForVendor}>Send OTP</button>

                            <button className="btn btn-main" onClick={handleSignAsVendor}>REGISTER</button>
                        </div>
                    </form>
                        <p className="mt-20">Already have an account ?<Link to="/Login">Login</Link></p>
                    </div>
                </div>
                </div>
            </div>
        </section>
    </div>
)
    
}
