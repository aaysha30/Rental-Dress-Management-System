import React, { useEffect, useState } from 'react'
import {Link, useParams} from 'react-router-dom'
import axios from 'axios'
import { useSelector } from 'react-redux';


export default function ProductByCategory() {
	const genderF='f';
    const genderM='m';
    const category1="Sherwani";
    const category2="Tuxedo";
    const category3="Kurta";
    const category4="Lehenga";
    const category5="Gown"; 
    const category6="Western";
	
	
    const fname=useSelector(state=>{ return state.fname});
    
    const f=fname.toUpperCase()
	let obj=useParams();
	let category=obj.category;
	console.log("hello"+""+category)
	const [getdata, setGetdata] = useState([]);

	useEffect(() =>{

		axios.get(`http://localhost:8080/category/searchByCategory/${category}`)
			.then(
				(productSpec) => {
					setGetdata(productSpec.data);
					console.log(productSpec.data)
			})
			.catch((error)=>{
				console.log(error)
			
			})
			
		}, []);

					
    return (

		<div>

			<React.Fragment>
			<section className="top-header">
                <div className="container">
                    <div className="row">
                        <div className="col-md-4 col-xs-12 col-sm-4">
                        <div className=" Fashion Logo">
                            <Link className="pull-left" to="/">
                            <img className="media-object" src="assets/images/logo/fas.jpg" width="80px" height="80px" alt="image" />
                             </Link>
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Site Logo --> */}
                            <div className="logo text-center">
                                <Link to="/">
							<h1>FASHION ON RENT</h1>

                                </Link>
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Cart --> */}
                            <ul className="top-menu text-right list-inline">
                                <li className="dropdown cart-nav dropdown-slide">
                                    <Link to="/cartsession" className="dropdown-toggle" ><i
                                            className="tf-ion-android-cart"></i>Cart</Link>
                                </li>
                                {/* <!-- / Cart --> */}


                                {/* <!-- Search --> */}
                                <li className="dropdown search dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" > HELLO {f}</Link>
                                    {/* <ul className="dropdown-menu search-dropdown">
                                        <li>
                                            <form action="post"><input type="search" className="form-control" placeholder="Search..." /></form>
                                        </li>
                                    </ul> */}
                                </li>
                                {/* <!-- / Search --> */}

                                {/* <!-- Languages --> */}
                                <li className="">
                                <Link to={"/login"}>Login</Link>
                                </li>
                                {/* <!-- / Languages --> */}

                            </ul>
                            {/* <!-- / .nav .navbar-nav .navbar-right --> */}
                        </div>
                    </div>
                </div>
            </section>
            {/* <!-- End Top Header Bar --> */}


            {/* <!-- Main Menu Section --> */}
             <section className="menu">
                <nav className="navbar navigation">
                    <div className="container">
                        <div className="navbar-header">
                            <h2 className="menu-title">Main Menu</h2>
                            <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                                aria-expanded="false" aria-controls="navbar">
                                <span className="sr-only">Toggle navigation</span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                            </button>
                        </div>
                        {/* <!-- / .navbar-header --> */}

                        {/* <!-- Navbar Links --> */}
                        <div id="navbar" className="navbar-collapse collapse text-center">
                            <ul className="nav navbar-nav">

                                {/* <!-- Home --> */}
                                <li className="dropdown ">
                                    <Link to="/">Home</Link>
                                </li>
                                {/* <!-- / Home --> */}

                                {/* <!-- Pages --> */}
                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                        role="button" aria-haspopup="true" aria-expanded="false">Catalogue <span
                                            className="tf-ion-ios-arrow-down"></span></Link>
                                    <div className="dropdown-menu">
                                        <div className="row">
                                            {/* <!-- For Him --> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                            <ul>
														<li className="dropdown-header">For Him</li>
														<li role="separator" className="divider"></li>
														 
                                                        <li><Link to={`/productByCategory/${category1}`}>Sherwani</Link></li>
                                                    <li><Link to={`/productByCategory/${category2}`}>Tuxedo</Link></li>
                                                    <li><Link to={`/productByCategory/${category3}`}>Kurta Pyjama</Link></li>
                                               
													</ul>
                                            </div>
                                            
                                            {/* <!--For Her--> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                            <ul>
														<li className="dropdown-header">For Her</li>
														<li role="separator" className="divider"></li>
                                                    <li><Link to={`/productByCategory/${category4}`}>Lehenga</Link></li>
                                                    <li><Link to={`/productByCategory/${category5}`}>Gowns</Link></li>
                                                    <li><Link to={`/productByCategory/${category6}`}>Western</Link></li>
                                                </ul>
                                            </div>
                                        </div>
                                        {/* <!-- / .row --> */}
                                    </div>
                                    {/* <!-- / .dropdown-menu --> */}
                                </li>
                                {/* <!-- / Pages --> */}

                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                    role="button" aria-haspopup="true" aria-expanded="false">Dashboard<span
                                        className="tf-ion-ios-arrow-down"></span></Link>

                                        <div className="dropdown-menu">
                                            <div className="row">
                                                
                                                {/* <!-- Contact --> */}
                                                <div className="col-lg-12 col-md-6 mb-sm-3">
                                                    <ul>
                                                        <li><Link to="/Order">Orders</Link></li>
                                                        <li><Link to="/profileDetails">Profile Details</Link></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            {/* <!-- / .row --> */}
                                        </div>
                                        {/* <!-- / .dropdown-menu --> */}
                                </li>
                            </ul>
                            {/*  / .nav .navbar-nav */}
                        </div>
                        {/* /.navbar-collapse  */}
                    </div>
                    {/* <!-- / .container --> */}
                </nav>
            </section> 

				<section className="page-header">
					<div className="container">
						<div className="row">
							<div className="col-md-12">
								<div className="content">
									<h1 className="page-name">Shop</h1>
									<ol className="breadcrumb">
										<li><Link to="index.html">Home</Link></li>
										<li className="active">shop</li>
									</ol>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section className="products section">
					<div className="container">
						<div className="row">
						
						{getdata.map((product)=>{
					const id=product.apparelID
					console.log(id)
							return(
								<>
									<div className="col-md-4">
										<div className="product-item">
											<div className="product-thumb">
												{/* <img className="img-responsive" src={product.image} alt="product-img" /> */}
												<img className="img-responsive" src={`data:image/jpg;base64,${product.image}`} alt="product-img" />
												
											</div>
											<div className="product-content">
												<h4>
														{product.description}
												</h4>
												<h3>
													<Link to={`/productdetails/${id}`} className="btn btn-main">
														SELECT
													</Link>
												</h3>
											</div>
										</div>
									</div>
								</>
							)//product.apparelid
						})}	


						</div>
					</div>
				</section>

				<footer className="footer section text-center">
					<div className="container">
						<div className="row">
							<div className="col-md-12">
								<ul className="social-media">
									<li>
										<Link to="https://www.facebook.com/themefisher">
											<i className="tf-ion-social-facebook"></i>
										</Link>
									</li>
									<li>
										<Link to="https://www.instagram.com/themefisher">
											<i className="tf-ion-social-instagram"></i>
										</Link>
									</li>
									<li>
										<Link to="https://www.twitter.com/themefisher">
											<i className="tf-ion-social-twitter"></i>
										</Link>
									</li>
									<li>
										<Link to="https://www.pinterest.com/themefisher/">
											<i className="tf-ion-social-pinterest"></i>
										</Link>
									</li>
								</ul>
								<ul className="footer-menu text-uppercase">
									<li>
										<Link to="contact.html">CONTACT</Link>
									</li>
									<li>
										<Link to="shop.html">SHOP</Link>
									</li>
									<li>
										<Link to="pricing.html">Pricing</Link>
									</li>
									<li>
										<Link to="contact.html">PRIVACY POLICY</Link>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</footer>    

			</React.Fragment>

		</div>

    )



}
