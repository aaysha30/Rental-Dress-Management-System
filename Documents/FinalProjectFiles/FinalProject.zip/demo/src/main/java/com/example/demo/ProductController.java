package com.example.demo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin("http://localhost:3000")
@RestController
@RequestMapping(path="/category")
public class ProductController {
	
	@Autowired
	AparelRepo arepo;
	//http://localhost:8080/category/searchByCategory/Sherwani
	
	@GetMapping("/searchByCategory/{category}")
	public List<AperalEntity> searchByCategory(@PathVariable("category") String cat) {
		System.err.println("Search by category : "+cat);
	List<AperalEntity>li=arepo.findByCate(cat);
	return li;
	}
	
	
	//example ->selected anyone sherwani from above list
	//http://localhost:8080/category/searchByApparelId/2
	
	@GetMapping("/searchByApparelId/{id}")
	public Optional<AperalEntity> getParticularInfo(@PathVariable("id") int id) {
		System.err.println("Search by id ");
		
		
		Optional<AperalEntity>product=arepo.findById(id);
		System.out.println(product.get().getSize()+" "+product.get().getRent_amount());
		
		return product;
	}
	
	//http://localhost:8080/category/searchByGender/
	@GetMapping("/searchByGender/{gender}")
	public List<AperalEntity> searchByGender(@PathVariable("gender") char gender) {
		
		 List<AperalEntity> li=	arepo.findByGender(gender);
		 System.err.println("Search By Gender");
		 if(li!=null) {
			 System.out.println("data present");
			 System.out.println(gender);
		 }
		 else {
			 System.out.println("data is not present");
		 }
		 return li;
	}
	
	
}
