import React, { useEffect, useState } from 'react'
import {Link, useParams} from 'react-router-dom'
import axios from 'axios'


export default function ProductCatalogue() {

	const {category} = useParams();

	const [getdata, setGetdata] = useState([]);


	useEffect(() =>{

		axios.get(`http://localhost:8080/category/searchByCategory/${category}`)
			.then(
				(productSpec) => {
					var showthedata = productSpec.data;
					setGetdata(showthedata.data)
			})
			.catch((error)=>{
				console.log(error)
			})
			
		}, []);

					
    return (

		<div>

			<React.Fragment>

			 {/* <!-- Top Header Bar --> */}
			 <section className="top-header">
                <div className="container">
                    <div className="row">
                        <div className="col-md-4 col-xs-12 col-sm-4">
                        <div className=" Fashion Logo">
                            <Link className="pull-left" to="/">
                            <img className="media-object" src="assets/images/logo/fas.jpg" alt="image" />
                             </Link>
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Site Logo --> */}
                            <div className="logo text-center">
                                <Link to="/">
							<h1>FASHION ON RENT</h1>

                                </Link>
                            </div>
                        </div>
                        <div className="col-md-4 col-xs-12 col-sm-4">
                            {/* <!-- Cart --> */}
                            <ul className="top-menu text-right list-inline">
                                <li className="dropdown cart-nav dropdown-slide">
                                    <Link to="/Cart" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"><i
                                            className="tf-ion-android-cart"></i>Cart</Link>
                                    <div className="dropdown-menu cart-dropdown">
                                        {/* <!-- Cart Item --> */}
                                        <div className="media">
                                            <Link className="pull-left" to="#!">
                                                <img className="media-object" src="assets/images/shop/cart/cart-1.jpg" alt="image" />
                                            </Link>
                                            <div className="media-body">
                                                <h4 className="media-heading"><Link to="#!">Ladies Bag</Link></h4>
                                                <div className="cart-price">
                                                    <span>1 x</span>
                                                    <span>1250.00</span>
                                                </div>
                                                <h5><strong>$1200</strong></h5>
                                            </div>
                                            <Link to="#!" className="remove"><i className="tf-ion-close"></i></Link>
                                        </div> 
                                        {/* <!-- Cart Item --> */}
                                        <div className="media">
                                            <Link className="pull-left" to="#!">
                                                <img className="media-object" src="images/shop/cart/cart-2.jpg" alt="image" />
                                            </Link>
                                            <div className="media-body">
                                                <h4 className="media-heading"><Link to="#!">Ladies Bag</Link></h4>
                                                <div className="cart-price">
                                                    <span>1 x</span>
                                                    <span>1250.00</span>
                                                </div>
                                                <h5><strong>$1200</strong></h5>
                                            </div>
                                            <Link to="#!" className="remove"><i className="tf-ion-close"></i></Link>
                                        </div>

                                        <div className="cart-summary">
                                            <span>Total</span>
                                            <span className="total-price">$1799.00</span>
                                        </div>
                                        <ul className="text-center cart-buttons">
                                            <li><Link to="/Cart" className="btn btn-small">View Cart</Link></li>
                                            <li><Link to="/Checkout" className="btn btn-small btn-solid-border">Checkout</Link></li>
                                        </ul>
                                    </div>
                                </li>
                                {/* <!-- / Cart --> */}


                                {/* <!-- Search --> */}
                                <li className="dropdown search dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown"><i
                                            className="tf-ion-ios-search-strong"></i> Search</Link>
                                    <ul className="dropdown-menu search-dropdown">
                                        <li>
                                            <form action="post"><input type="search" className="form-control" placeholder="Search..." /></form>
                                        </li>
                                    </ul>
                                </li>
                                {/* <!-- / Search --> */}

                                {/* <!-- Languages --> */}
                                <li className="Login">
                                    
                                    <Link to={"/Login"}>Login</Link>
                                </li>
                                {/* <!-- / Languages --> */}

                            </ul>
                            {/* <!-- / .nav .navbar-nav .navbar-right --> */}
                        </div>
                    </div>
                </div>
            </section>
            {/* <!-- End Top Header Bar --> */}


            {/* <!-- Main Menu Section --> */}
             <section className="menu">
                <nav className="navbar navigation">
                    <div className="container">
                        <div className="navbar-header">
                            <h2 className="menu-title">Main Menu</h2>
                            <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar"
                                aria-expanded="false" aria-controls="navbar">
                                <span className="sr-only">Toggle navigation</span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                                <span className="icon-bar"></span>
                            </button>
                        </div>
                        {/* <!-- / .navbar-header --> */}

                        {/* <!-- Navbar Links --> */}
                        <div id="navbar" className="navbar-collapse collapse text-center">
                            <ul className="nav navbar-nav">

                                {/* <!-- Home --> */}
                                <li className="dropdown ">
                                    <Link to="/">Home</Link>
                                </li>
                                {/* <!-- / Home --> */}

                                {/* <!-- Elements --> */}
                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                        role="button" aria-haspopup="true" aria-expanded="false">Cart <span
                                            className="tf-ion-ios-arrow-down"></span></Link>
                                    <div className="dropdown-menu">
                                        <div className="row">

                                            {/* <!-- Basic --> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                                <ul>
                                                    <li className="dropdown-header">Pages</li>
                                                    <li role="separator" className="divider"></li>
                                                    <li><Link to="/Checkout">Checkout</Link></li>
                                                    <li><Link to="/Cart">Cart</Link></li>
                                                    

                                                </ul>
                                            </div>

                                           
                                        </div>
                                        {/* <!-- / .row --> */}
                                    </div>
                                    {/* <!-- / .dropdown-menu --> */}
                                </li>
                                {/* <!-- / Elements --> */}


                                {/* <!-- Pages --> */}
                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                        role="button" aria-haspopup="true" aria-expanded="false">Catalogue <span
                                            className="tf-ion-ios-arrow-down"></span></Link>
                                    <div className="dropdown-menu">
                                        <div className="row">
                                            {/* <!-- For Him --> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                            <ul>
														<li className="dropdown-header">For Him</li>
														<li role="separator" className="divider"></li>
														<li><Link to="/products/sherwani">Sherwani</Link></li>
														<li><Link to="/products/tuxedo">Tuxedo</Link></li>
														<li><Link to="/products/kurta">Kurta Pyjama</Link></li>
													</ul>
                                            </div>
                                            
                                            {/* <!--For Her--> */}
                                            <div className="col-lg-6 col-md-6 mb-sm-3">
                                            <ul>
														<li className="dropdown-header">For Her</li>
														<li role="separator" className="divider"></li>
														<li><Link to="/products/lehenga">Lehenga</Link></li>
														<li><Link to="/products/gown">Gowns</Link></li>
														<li><Link to="/products/indowestern">Indo-Western</Link></li>
													</ul>
                                            </div>
                                        </div>
                                        {/* <!-- / .row --> */}
                                    </div>
                                    {/* <!-- / .dropdown-menu --> */}
                                </li>
                                {/* <!-- / Pages --> */}

                                <li className="dropdown dropdown-slide">
                                    <Link to="#!" className="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="350"
                                    role="button" aria-haspopup="true" aria-expanded="false">Dashboard<span
                                        className="tf-ion-ios-arrow-down"></span></Link>

                                        <div className="dropdown-menu">
                                            <div className="row">
                                                
                                                {/* <!-- Contact --> */}
                                                <div className="col-lg-12 col-md-6 mb-sm-3">
                                                    <ul>
                                                        <li><Link to="/Order">Orders</Link></li>
                                                        <li><Link to="/profileDetails">Profile Details</Link></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            {/* <!-- / .row --> */}
                                        </div>
                                        {/* <!-- / .dropdown-menu --> */}
                                </li>
                            </ul>
                            {/* <!-- / .nav .navbar-nav --> */}
                        </div>
                        {/* <!--/.navbar-collapse --> */}
                    </div>
                    {/* <!-- / .container --> */}
                </nav>
            </section> 
				<section className="page-header">
					<div className="container">
						<div className="row">
							<div className="col-md-12">
								<div className="content">
									<h1 className="page-name">Shop</h1>
									<ol className="breadcrumb">
										<li><Link to="index.html">Home</Link></li>
										<li className="active">shop</li>
									</ol>
								</div>
							</div>
						</div>
					</div>
				</section>

				<section className="products section">
					<div className="container">
						<div className="row">
						
						{getdata.map((product)=>{
					
							return(
								<>
									<div className="col-md-4">
										<div className="product-item">
											<div className="product-thumb">
												{/* <span className="bage">Sale</span> */}
												<img className="img-responsive" src={product.image} alt="product-img" />
												<div className="preview-meta">
													{/* <ul>
														<li>
															<span  data-toggle="modal" data-target="#product-modal">
																<i className="tf-ion-ios-search-strong"></i>
															</span>
														</li>
														<li>
															<Link to="#!" ><i className="tf-ion-ios-heart"></i></Link>
														</li>
														<li>
															<Link to="#!"><i className="tf-ion-android-cart"></i></Link>
														</li>
													</ul> */}
												</div>
											</div>
											<div className="product-content">
												<h4>
													<Link to={`/productdetails/${product.description}`}>
														{product.description}
													</Link>
												</h4>
												<p className="price" name="pcost">{product.rent_amount}</p>
											</div>
										</div>
									</div>
								</>
							)
						})}	


						</div>
					</div>
				</section>

				<footer className="footer section text-center">
					<div className="container">
						<div className="row">
							<div className="col-md-12">
								<ul className="social-media">
									<li>
										<Link to="https://www.facebook.com/themefisher">
											<i className="tf-ion-social-facebook"></i>
										</Link>
									</li>
									<li>
										<Link to="https://www.instagram.com/themefisher">
											<i className="tf-ion-social-instagram"></i>
										</Link>
									</li>
									<li>
										<Link to="https://www.twitter.com/themefisher">
											<i className="tf-ion-social-twitter"></i>
										</Link>
									</li>
									<li>
										<Link to="https://www.pinterest.com/themefisher/">
											<i className="tf-ion-social-pinterest"></i>
										</Link>
									</li>
								</ul>
								<ul className="footer-menu text-uppercase">
									<li>
										<Link to="contact.html">CONTACT</Link>
									</li>
									<li>
										<Link to="shop.html">SHOP</Link>
									</li>
									<li>
										<Link to="pricing.html">Pricing</Link>
									</li>
									<li>
										<Link to="contact.html">PRIVACY POLICY</Link>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</footer>    

			</React.Fragment>

		</div>

    )
}
