import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { axios } from 'axios';


export default function Signup() {
    

    const [first_name, setFirst_name] = useState('');
    const [last_name, setLast_name] = useState('');
    const [mobile_no, setMobile_no] = useState('');
    const [uname, setUname] = useState('');
    const [password, setPassword] = useState('');
    const [gender, setGender] = useState('');

    const navigateto = useNavigate();

    const handleFname = (em) => {
        setFirst_name(em.target.value);
    }
    const handleLname = (em) => {
        setLast_name(em.target.value);
    }
    const handleMoblieno = (em) => {
        setMobile_no(em.target.value);
    }
    const handleEmail = (em) => {
       setUname(em.target.value);
    }
    const handlePassword = (pwd) => {
        setPassword(pwd.target.value);
    }
    const handleGender = (em) => {
        setGender(em.target.value);
    }

    const handleCustomerSignUp = (e) => {
        e.preventDefault();
        axios.post('http://localhost:8080/registration', {
            first_name : first_name,
            last_name : last_name,
            mobile_no : mobile_no,
            uname : uname,
            password : password,
            gender : gender,



        })
            .then(result => {
                navigateto('/');
            })
            .catch(error => {
                console.log(error);
            })}
    return (
        <div>
            <section className="signin-page account homeimage">
                <div className="container">
                    <div className="row justify-content-center">
                    <div className="col-md-6 col-md-offset-3">
                        <div className="block text-center my-3">
                        <h2 className="text-center">Customer SignUp</h2>
                        <form className="text-left clearfix my-3" action="/">
                            <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="First Name" value={first_name} name='first_name' onChange={handleFname} required pattern='[A-Z]{1}[a-z]{1,20}' />
                            </div>
                            <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="Last Name" value={last_name} name='last_name' onChange={handleLname} required pattern='[A-Z]{1}[a-z]{1,20}' />
                            </div>
                            <div className="form-group">
                            <input type="text" className="form-control my-3"  placeholder="Mobileno" value={mobile_no} name='mobile_no' onChange={handleMoblieno} required pattern='[0-9]{10}' />
                            </div>
                            <div className="form-group">
                            <input type="email" className="form-control my-3"  placeholder="Email" value={uname} name='uname' onChange={handleEmail} required pattern='^[a-z0-9]\@[a-z]\.[a-z]$' />
                            </div>
                            <div className="form-group">
                            <input type="password" className="form-control my-3"  placeholder="Password" value={password} name='password' onChange={handlePassword} required />
                            </div>
                            <div className="form-group" onChange={handleGender}>
                            <h4>Gender &nbsp;&nbsp;
                            <input type="radio"  value="M" name='gender'/> Male &nbsp;&nbsp;
                            <input type="radio"  value="F" name='gender'/> Female </h4>                     
                            </div>
                            <div className="text-center">
                            <button  className="btn btn-main text-center my-3" onClick={handleCustomerSignUp}>Sign In</button>
                            </div>
                        </form>
                        <p className="mt-20">Already have an account ? <Link to="/Login">Login</Link></p>
                        </div>
                    </div>
                    </div>
                </div>
            </section>
        </div>
    )
}
