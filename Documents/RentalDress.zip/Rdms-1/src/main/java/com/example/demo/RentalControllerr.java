package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;





@Controller
public class RentalControllerr {
@Autowired
UserRepo urepo;

@GetMapping(value="/login")
public String login() {
	System.out.println("Login");
	return "login";
}
@GetMapping(value="/verify")
public String verify(@RequestParam("uname") String username,@RequestParam("pwd") String password) {
	List<UserEntity>li=urepo.findAll();
	int flag=0 ;
	for(UserEntity u:li) {
		if(u.getFirst_name().equals(username) && u.getPassword().equals(password)) {
			flag=1; break;
		}
		else {
			flag=0;
		}
	}
	if(flag==1) {
		return "index";
	}
	else {
		return "login";
	}
}
}
