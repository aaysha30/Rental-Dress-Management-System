package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/categor")
public class MyRentalRestController {
	@Autowired
	AparelRepo arepo;
	@GetMapping("/searchByCategory")
	public List<AperalEntity> searchByCategory() {
	//List<AperalEntity>li=arepo.findByCategory(category);
	//	List<AperalEntity>li=arepo.findAll();
	//List<AperalEntity>li=arepo.findByGender('M');
		List<AperalEntity>li=arepo.findByCate("Kurta");
		
	return li;
		
}
}
