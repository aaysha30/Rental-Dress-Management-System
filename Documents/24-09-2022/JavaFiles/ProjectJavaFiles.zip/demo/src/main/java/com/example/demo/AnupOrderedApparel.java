package com.example.demo;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="anup_order_details2")
public class AnupOrderedApparel {

@Id 
@GeneratedValue
@Column
private String id; 
@Column
private int apparelId;
@Column
private String order_id;
	

	public AnupOrderedApparel(int apparelId, String order_id) {
	super();
	this.apparelId = apparelId;
	this.order_id = order_id;
}

	public int getApparelId() {
		return apparelId;
	}

	public void setApparelId(int apparelId) {
		this.apparelId = apparelId;
	}

	public AnupOrderedApparel() {
		super();
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrder_Id() {
		return order_id;
	}

	public void setOrder_Id(String order_Id) {
		this.order_id = order_Id;
	}
}
