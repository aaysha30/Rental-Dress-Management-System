package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AnupAController {
	@Autowired
	AnuOrderRepo orepo;
	@Autowired
	AnupOrderApparelRepo arepo;
@GetMapping("/myController")
public void geCt() {
	System.out.println("Hiiiiiiiiiiiiiiiiiii");
}

@PostMapping("/placeorderdress")
public Message placeOrderDress(@RequestBody OrderInfo o) {
	AnupOrderEntity _order = orepo.save(new AnupOrderEntity(o.getOrder_id(), o.getRent_amount(), o.getDeposit_amount(), o.getTotal_amount(), o.getDelievery_address(), o.getDate_of_dispatch(), o.getDate_of_return(), o.getCid()));
		
	System.err.println(o.getDelievery_address());
	System.out.println();
		List<Integer>li=o.getApparels();
		if(li!=null) {
			System.out.println("Ok");
		}
		else {
			System.out.println("Not ok");
		}
		String oid= o.getOrder_id();
		for(int air:li) {
			AnupOrderedApparel oa=new AnupOrderedApparel(air,oid);
			arepo.save(oa);
		}
		
	
	return new Message("ok");
}
}
