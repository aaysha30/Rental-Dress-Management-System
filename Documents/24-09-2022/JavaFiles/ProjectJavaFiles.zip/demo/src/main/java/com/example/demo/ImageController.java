package com.example.demo;

import java.io.IOException;
import java.net.http.HttpHeaders;
import java.sql.SQLException;
import java.util.Base64;
import java.util.Optional;
import java.util.concurrent.ThreadLocalRandom;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
@RequestMapping(path="/filedata")
public class ImageController 
{
	@Autowired
	ImageRepo repo;

//	@GetMapping("/view")    //take byte[] as datatype in imageEntity
//	public String f2(Model model)
//	{
//		System.out.println("1");
//		Optional<ImageEntity> img = repo.findById(1);
//		ImageEntity entity = null;
//		if(img.isPresent())
//		{
//			entity = img.get();
//		}
//		String encodedString = Base64.getEncoder().encodeToString(entity.getImage());
//		model.addAttribute("photo", encodedString);
//		return "get";
//	}
	
	@GetMapping("/database")    //take blob as datatype in imageEntity
	public ResponseEntity<byte[]> fromDatabaseAsResEntity() 
	        throws SQLException {

		Optional<ImageEntity> entity = repo.findById(1);
		byte[] imageBytes = null;
		if (entity.isPresent()) {
			imageBytes = entity.get().getImage().getBytes(1,
						(int) entity.get().getImage().length());
			System.out.println(imageBytes);
		}
		
		return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(imageBytes);
	}
	
	
	
//-----------------------------------------------------------------
//	@PostMapping(value="/image")               //take byte[] as datatype in imageEntity
//	public String f1(@RequestParam MultipartFile file)  
//	{
//		//String fileName = StringUtils.cleanPath(file.getOriginalFilename());
//		try {
//			ImageEntity img = new ImageEntity(file.getBytes());
//			repo.save(img);
//		}
//		catch (Exception e) {
//			System.out.println("Exception Occured");
//		}
//		return "inserted";
//	}
//-------------------------------------------------------------------	

}