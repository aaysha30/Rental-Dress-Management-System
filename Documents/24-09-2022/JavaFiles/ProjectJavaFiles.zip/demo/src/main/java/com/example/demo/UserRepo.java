package com.example.demo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
@Repository
public interface UserRepo extends JpaRepository<UserEntity, Integer>{
	
	@Query( value="from com.example.demo.UserEntity u where u.emailId= :email")
	public UserEntity findByEmail(@Param("email") String email);
	//public UserEntity findByEmail(@Param("email") String email,String pwd);
}
