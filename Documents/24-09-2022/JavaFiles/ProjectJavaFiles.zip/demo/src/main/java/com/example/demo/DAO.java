package com.example.demo;

import java.util.List;



public class DAO {
public int getdata(List<UserEntity> li,UserInfo ui,int id){
	
	int flag=0 ;
	for(UserEntity u:li) {
		if(u.getEmailId().equals(ui.getUname())&& u.getPassword().equals(ui.getPassword())) {
			System.out.println(u.getEmailId()+" "+ui.getUname());
			System.out.println(u.getPassword()+" "+ui.getPassword());
			id=u.getCustomerId();
			flag=1; break;
		}
		else {
			System.out.println("else..");
			flag=0;
		}
	}
	if(flag==1) {
//		System.err.println("Ok");
//		return new Message("ok",id);
		return id;
		
	}
	else {
//		System.err.println("Not Ok");
//		return new Message("Not Ok",id);
		return id;
	}
}
public UserEntity insert(RegistrationPojo ue1) {
	UserEntity ue=new UserEntity(19,ue1.getFirst_name(),ue1.getLast_name(),ue1.getMobile_no(),ue1.getEmail_Id(),ue1.getPassword(),ue1.getGender().charAt(0));
	return ue;
}
public void update(String email,String pwd) {
	
}
}
