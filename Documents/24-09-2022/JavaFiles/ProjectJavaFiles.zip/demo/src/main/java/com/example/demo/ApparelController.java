package com.example.demo;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin
@RestController
@RequestMapping(path="/apparel")
public class ApparelController {

	@Autowired
	AparelRepo repo;

	@PostMapping("/insertApparel")
	public String insertApparel(@RequestParam int vendorId,@RequestParam String description,@RequestParam String cate,
			@RequestParam int deposit_amount,@RequestParam int rent_amount,@RequestParam String size,
			@RequestParam String gender,@RequestParam MultipartFile image) {
		AperalEntity obj;
		System.out.println("Insert apperal");
		try {
			obj = new AperalEntity(68,size,description,cate,rent_amount,deposit_amount,vendorId,gender.charAt(0),"available",image.getBytes(),21);
			repo.save(obj);
		} catch (IOException e) {
			System.out.println("Exception occured");
		}
		return "insert done";
	}
	
//	@GetMapping("/getApparel")
//	public List<ApparelEntity2> getCollection() {
//		List<ApparelEntity2> list = repo.findAll();
//		return list;
//	}
	
	@GetMapping("/getByVendorId/{vendorId}")
	public List<AperalEntity> getById(@PathVariable("vendorId")int vendorId){
		
		System.err.println("Vendor id : "+vendorId);
		List<AperalEntity> list = repo.findByVendorID(vendorId);
		if(list!=null) {
		System.err.println("Prsent");
		}
		else {
			System.err.println("Not Prsent");
		}
		return list;
	}
	
//	@DeleteMapping("/deleteByApparelId/{apparelId}")
//	public String deleteApparel(@PathVariable int apparelId) {
//		repo.deleteById(apparelId);
//		return "deleted";
//	}
	
}





