package com.example.demo;

import java.sql.Blob;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="image")
public class ImageEntity 
{
	@Id
	@GeneratedValue
	@Column
	private int id;
	
	@Column
	private Blob image;

	public ImageEntity() {
		// TODO Auto-generated constructor stub
	}
	
	public ImageEntity(Blob image) {
		super();
//		this.id = id;
		this.image = image;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Blob getImage() {
		return image;
	}

	public void setImage(Blob image) {
		this.image = image;
	}
	
	
}
