import {atom} from 'jotai';

export const customerid = atom(null);