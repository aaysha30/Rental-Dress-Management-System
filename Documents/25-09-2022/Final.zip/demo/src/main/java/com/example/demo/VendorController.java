
package com.example.demo;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.Message;
import com.example.demo.UserInfo;


@CrossOrigin("http://localhost:3000")
@RestController

@RequestMapping(path="/vendor")
public class VendorController {

	@Autowired
	VendorRepo vRepo;
	@PostMapping("/verify")
	
	//http://localhost:8080/vendor/verify
	public Message verify(@RequestBody UserInfo ui) {
		List<VendorEntity>li=vRepo.findAll();
	int id=0;
		System.err.println(ui.getUname());
		int flag=0 ;
		for(VendorEntity u:li) {
			if(u.getEmailId().equals(ui.getUname())&& u.getPassword().equals(ui.getPassword())) {
				System.out.println(u.getEmailId()+" "+ui.getUname());
				System.out.println(u.getPassword()+" "+ui.getPassword());
				id=	u.getVendorId();
				flag=1;
				break;
			}
			else {
				System.out.println("else..");
				flag=0;
			}
			
		}
		if(flag==1) {
			System.out.println("ok");
			return new Message("ok",id);
		}
		else {
			System.out.println("Not ok");
			return new Message("not ok",id);
		}
	
	}
	//Registration
	@PostMapping("/addvendor")
	public Message addVendor(@RequestBody VendorEntity ve ) {
		VendorEntity vendor = new VendorEntity(ve.getFirst_name(),ve.getLast_name(),ve.getMobile_no(),ve.getEmailId(),ve.getPassword(),ve.getPassword());
		System.out.println("Vendor Regist");
		vRepo.save(vendor);
		return new Message("ok");
	}
	
	//forgot password
	@PutMapping("/forgotpassword/{uname}/{newpwd}")
	public String forgotPassword(@PathVariable("uname") String uname, @PathVariable("newpwd") String newpwd) {
		Optional<VendorEntity> obj = vRepo.findByEmailId(uname);
		System.out.println("Forgot Password");
		if(obj.isPresent()){
			VendorEntity vendor = obj.get();
			vendor.setPassword(newpwd);
			vRepo.save(vendor);
			return "vendor login";
		}
		else
			return "Invalid credentials";
	}
	
	
}
