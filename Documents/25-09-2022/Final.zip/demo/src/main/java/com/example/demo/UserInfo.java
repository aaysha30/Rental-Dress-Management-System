package com.example.demo;

public class UserInfo {
private String uname;
private String password;

public UserInfo() {
	super();
}

public String getUname() {
	return uname;
}

public void setUname(String uname) {
	this.uname = uname;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}



}
