package com.example.demo;

public class Message {
private String msg;
private int id;
private String fname;
public Message(String msg, int id, String fname) {
	super();
	this.msg = msg;
	this.id = id;
	this.fname = fname;
}
public Message(String msg, int id) {
	super();
	this.msg = msg;
	this.id = id;
}
public String getFname() {
	return fname;
}
public void setFname(String fname) {
	this.fname = fname;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Message(String msg) {
	super();
	this.msg = msg;
}
public String getMsg() {
	return msg;
}
Message(){
	
}

public void setMsg(String msg) {
	this.msg = msg;
}

}
