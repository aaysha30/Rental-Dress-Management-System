package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin("http://localhost:3000")
@RestController
public class OrderController {
	@Autowired
	OrderRepo orepo;
	@Autowired
	OrderApparelRepo arepo;
@GetMapping("/myController")
public void geCt() {
	System.out.println("Hiiiiiiiiiiiiiiiiiii");
}

@PostMapping("/placeorderdress")
public Message placeOrderDress(@RequestBody OrderInfo o) {
	System.err.println("Place order");
	OrderEntity _order = orepo.save(new OrderEntity(o.getOrder_id(), o.getRent_amount(), o.getDeposit_amount(), o.getTotal_amount(), o.getDelievery_address(), o.getDate_of_dispatch(), o.getDate_of_return(), o.getCid()));
		orepo.save(_order);
	System.err.println(o.getDelievery_address());
//	System.out.println();
		List<Integer>li=o.getAid();
		if(li!=null) {
			System.out.println("Ok");
		}
		else {
			System.out.println("Not ok");
		}
		int oid= o.getOrder_id();
		for(int air:li) {
			OrderedApparelEntity oa=new OrderedApparelEntity(air,oid);
			arepo.save(oa);
		}
		
	
	return new Message("ok");

}
}