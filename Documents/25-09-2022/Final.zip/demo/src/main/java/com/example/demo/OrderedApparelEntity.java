package com.example.demo;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

@Entity
@Table(name="anup_order_details3")
public class OrderedApparelEntity {

@Id 
@GeneratedValue
@Column
private int id; 
@Column
private int apparelId;
@Column
private int  order_id;
	

	public OrderedApparelEntity(int apparelId, int order_id) {
	super();
	this.apparelId = apparelId;
	this.order_id = order_id;
}

	public int getApparelId() {
		return apparelId;
	}

	public void setApparelId(int apparelId) {
		this.apparelId = apparelId;
	}

	public OrderedApparelEntity() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrder_Id() {
		return order_id;
	}

	public void setOrder_Id(int order_Id) {
		this.order_id = order_Id;
	}
}
