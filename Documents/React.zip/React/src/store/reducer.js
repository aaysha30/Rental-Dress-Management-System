// import {createStore} from 'redux';
// //import { configureStore } from '@reduxjs/toolkit'
// const counterReducer = (state={uname:"",password:""},action)=>{

//     if(action.type==="save")
//     {     console.log("here")
//         return {
//             uname:action.payload.uname,
//             password:action.payload.password,
            
//         };
//     }
    
//     return state;

// } 

// const store = createStore(counterReducer);
// /*
// const store = configureStore({
//     counterReducer,
//   })
// */
// export default store;

import { configureStore } from '@reduxjs/toolkit'

const counterReducer = (state={uname:"",password:"",role:"",cart:[],roleId:''},action)=>{

    if(action.type==="save")
    {     console.log("reducer store")
        return {
            uname:action.payload.uname,
            password:action.payload.password,
            role:action.payload.role,
            roleId:action.payload.roleId
        };
    }
    
    return state;

} 


 const store = configureStore({
    reducer:counterReducer,
})

export default store;
