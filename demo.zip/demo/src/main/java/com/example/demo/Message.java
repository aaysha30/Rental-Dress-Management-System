package com.example.demo;

public class Message {
private String msg;

public Message(String msg) {
	super();
	this.msg = msg;
}
public String getMsg() {
	return msg;
}
Message(){
	
}
public void setMsg(String msg) {
	this.msg = msg;
}

}
