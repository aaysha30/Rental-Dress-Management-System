package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
public class LoginController {
	@Autowired
	UserRepo urepo;
	@PostMapping("/verify")
	public String verify(@RequestBody UserInfo ui) {
		List<UserEntity>li=urepo.findAll();
		int flag=0 ;
		for(UserEntity u:li) {
			if(u.getFirst_name().equals(ui.getUname()) && u.getPassword().equals(ui.getPassword())) {
				flag=1; break;
			}
			else {
				flag=0;
			}
		}
		if(flag==1) {
			System.out.println("Ok");
			return "ok";
		}
		else {
			System.out.println("Not Ok");
			return "nt ok";
		}
	}

}
