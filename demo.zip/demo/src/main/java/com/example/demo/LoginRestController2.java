package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class LoginRestController2 {

@Autowired
UserRepo urepo;
@GetMapping("/loginn2")
public String verify(@RequestParam("uname") String username,@RequestParam("pwd") String password) {
List<UserEntity>li=urepo.findAll();
int flag=0 ;
for(UserEntity u:li) {
	if(u.getFirst_name().equals(username) && u.getPassword().equals(password)) {
		flag=1; break;
	}
	else {
		flag=0;
	}
}
if(flag==1) {
	return "OK";
}
else {
	return "Not Ok";
}
}

}
