package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController

public class ReactRestController {
	@Autowired
	UserRepo u;
	@PostMapping("/myrest")
public Message getMe(@RequestBody UserInfo ui) {
	UserEntity ue=u.findByEmail(ui.getUname());
	if(ue!=null) {
		System.out.println("Ok");
		return new Message("ok");
	}
	System.out.println("Not ok");
	return new Message("not ok");
}
}
